using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Identity.Client.Platforms.Features.DesktopOs.Kerberos;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;

namespace Tipsgenerator.Pages.Accounts
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public Credentials Credential { get ; set; }
        

        public void OnGet()
        {
           
        }

        public async Task <IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();
            
            if (Credential.Password == "password")
            {
                var claims = new List<Claim> {
                    new Claim(ClaimTypes.Name, Credential.UserName),
                    
                    
                };
                
                var identity = new ClaimsIdentity(claims, "MyCookieAuth");
                ClaimsPrincipal claimsPrincipal = new ClaimsPrincipal(identity);

                await HttpContext.SignInAsync("MyCookieAuth", claimsPrincipal);

                return RedirectToPage("/Index");
            }
            return Page();
        }

        public class Credentials 
        {
            [Required]
            public string UserName { get; set; }

            [Required]
            [DataType(DataType.Password)]
            public string Password { get; set; }
        }
        
    }
}
