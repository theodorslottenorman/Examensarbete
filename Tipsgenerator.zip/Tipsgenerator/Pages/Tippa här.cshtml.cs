using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Tipsgenerator.Models;

namespace Tipsgenerator.Pages
{
    [Authorize]
    public class Tippa_här_Model : PageModel
    {
        
        private readonly ApplicationDbContext _acc;

        public Tippa_här_Model(ApplicationDbContext acc)
        {
            _acc = acc;
        }

        public IEnumerable<Matches> Displayresults { get; set; }
        public async Task OnGet()
        {
            Displayresults = await _acc.Matches.ToListAsync();
        }
        
    }
}
