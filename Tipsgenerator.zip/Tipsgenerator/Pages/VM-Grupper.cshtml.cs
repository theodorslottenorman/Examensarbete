using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Tipsgenerator.Pages
{
    public class VM_GrupperModel : PageModel
    {
        public void OnGet()
        {
        }

    }
}
