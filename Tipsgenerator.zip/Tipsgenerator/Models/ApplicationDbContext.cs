﻿using Microsoft.EntityFrameworkCore;

namespace Tipsgenerator.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        public DbSet<Matches> Matches { get; set; }
    }
}
