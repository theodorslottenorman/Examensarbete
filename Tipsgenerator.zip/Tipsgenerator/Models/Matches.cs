﻿using System.ComponentModel.DataAnnotations;

namespace Tipsgenerator.Models
{
    public class Matches
    {
        [Key]
        public int Id { get; set; }

        public string? Match { get; set; }
        public string? Val1 { get; set; }
        public string? ValX { get; set; }
        public string? Val2 { get; set; }
        public string? Rätt { get; set; }
    }
}
